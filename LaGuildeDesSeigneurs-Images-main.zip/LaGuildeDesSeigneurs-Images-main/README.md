# LaGuildeDesSeigneurs-Images
Les images enregistrées dans ce dépôt sont soumises à licence, elles ne peuvent DONC PAS être ré-utilisées en dehors de ce projet.
Merci de votre compréhension