ChangeLog

## v0.4

- Redimensionnement des images (25/10/2021)
- Séparation des images en sous-répertoires (25/10/2021)

## v0.3

- Ajout des images des cartes (27/09/2021)

## v0.2

- Renommage des fichiers (16/09/2021)

## v0.1

- Ajout de simages (16/09/2021)
- Modification du README (16/09/2021)
